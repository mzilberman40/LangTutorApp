# Langs2Brain – Strategic Project Overview

---

## 1. Vision & Value Proposition

Create a multi‑platform, AI‑assisted language‑learning service that supplies **personalised audio lessons** (native→target phrases with TTS) and adapts to each learner’s progress.

---

## 2. Target Users

- Independent adult learners (CEFR A1–C2)
- Initially single‑user; roadmap includes multi‑user classrooms & B2B licensing

---

## 3. MVP Scope (Phase 1)

| Area                   | Must‑have                                             | Nice‑to‑have                     |
| ---------------------- | ----------------------------------------------------- | -------------------------------- |
| **Content generation** | `word2phrases` pipeline, CEFR tagging, idioms support | Automatic grammar notes          |
| **Audio generation**   | Study MP3 & Training MP3 with pauses                  | Background ambience, intro/outro |
| **Data storage**       | SQLite (Word, Phrase, Lesson, LessonFile)             | Migrate to PostgreSQL            |
| **API**                | DRF endpoints for words → phrases, lesson build       | OAuth JWT auth                   |
| **UI**                 | Admin panel; CLI                                      | Web SPA; Telegram bot            |

---

## 4. Technical Architecture (current proposal)

- **Backend:** Django 5 + DRF
- **TTS Engine:** Pluggable (Google TTS → ElevenLabs later)
- **Storage:** Local files in `/lessons/`; switch to S3‑compatible later
- **Workers:** Celery for async audio generation

```
client → DRF API → DB → Celery task → TTS → MP3 → DB link
```

---

## 5. Data Model (v0.1)

- **Word** (id, text, language)
- **WordTranslation** (word↔translation, note)
- **Phrase** (id, native_text, target_text, cefr, category, M2M words)
- **Lesson** (number, created_at, M2M phrases)
- **LessonFile** (lesson, file_type, file)

> *Multi‑user support will add a **User** FK to Lesson and optionally to Phrase.*

---

## 6. Audio Generation Workflow

1. Scheduler selects next lesson (≤ `LESSON_LENGTH`).
2. Celery task builds `lesson_NN.txt`.
3. TTS renders native & target audio at respective speeds.
4. FFmpeg concatenates with pauses; outputs study/training MP3.
5. File paths stored in `LessonFile`.

---

## 7. Interfaces Roadmap

1. **Admin / CLI** – manage seed words & trigger builds.
2. **Web UI** – dashboard, audio player, progress stats.
3. **Telegram bot** – quick access to latest lesson.
4. **Mobile app** – long‑term.

---

## 8. Milestone Timeline (tentative)

| Month | Goal                                                 |
| ----- | ---------------------------------------------------- |
| M0    | Repo init, Django project, models, seed loader       |
| M1    | word2phrases service → DB; lesson builder writes TXT |
| M2    | TTS & MP3 pipelines (study / training)               |
| M3    | DRF API + simple React UI                            |
| M4    | Telegram bot MVP                                     |

---

## 9. Future Enhancements

- Adaptive spaced‑repetition algorithm
- User speech recording & pronunciation scoring
- Team / classroom mode
- Marketplace for community‑shared phrase decks

---

## 10. Open Questions (need your input)

1. **Languages in scope for launch:** Phase 1 – ru → en_GB (Russian native, British English target). Next: Hebrew, Portuguese, Dutch, Italian. In later phases, Russian may also be a target language.
