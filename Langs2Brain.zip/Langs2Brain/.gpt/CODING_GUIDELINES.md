# Lang2Brain App – Coding Guidelines (v1.1)

---

## 1. Repository

- **Origin:** [https://github.com/mzilberman40/LangTutorApp.git](https://github.com/mzilberman40/LangTutorApp.git)  
- **Default branch:** `main`

---

## 2. Development Environment

| Item        | Requirement                          |
|-------------|--------------------------------------|
| IDE         | **PyCharm Pro 2025.1.1.1** (or later)|
| Python      | 3.12                                 |
| Project dir | `H:\Coding\Projects\Lang2Brain`      |
| Virtual env | `H:\Coding\.venvs\Lang2Brain`        |
| OS          | Windows 11                           |

---

## 3. Workflow

- **TDD**: Write a failing test → Implement code → Make the test pass.

---

## 4. Docstrings & API Documentation ✔ (item 16)

- Follow the **Google** docstring style.
- Every **public function, class, and method** must have a docstring.
- Use the following section order: `Args`, `Returns`, `Raises`, `Example`.

### Example

```python
def slugify(text: str) -> str:
    """Convert text to a URL-friendly slug.

    Args:
        text: Raw input string from the user.

    Returns:
        A lowercase string containing letters, digits and hyphens only.

    Raises:
        ValueError: If *text* is empty.
    """
```

---

## 5. Logging ✔ (item 17)

| Level      | When to Use                                      |
|------------|--------------------------------------------------|
| `DEBUG`    | Verbose, step-by-step info useful during dev     |
| `INFO`     | High-level application flow                      |
| `WARNING`  | Recoverable problems, retries                    |
| `ERROR`    | Unhandled exceptions that don’t crash the service|
| `CRITICAL` | The service is unusable                          |

- Use the root logger via `logging.getLogger(__name__)`
- **Never** use `print()`
- In production, emit **JSON logs** via `logging_config.py`

---

## 6. Secrets & Configuration ✔ (item 19)

- **Never** commit credentials, API keys, or `.env` files.
- Configuration hierarchy (highest priority first):
  1. Environment variables
  2. `.env` file (excluded from Git)
  3. Default values in `settings.py`

### Configuration Example

Use the [`environs`](https://pypi.org/project/environs/) package and a `config/config.py` file like this:

```python
from dataclasses import dataclass
from environs import Env

@dataclass(frozen=True)
class TgBot:
    token: str  # Telegram bot token
    admin_ids: list[int]  # List of admin user IDs

@dataclass(frozen=True)
class Config:
    tg_bot: TgBot

def load_config(path: str | None = None) -> Config:
    env = Env()
    env.read_env(path)
    return Config(
        tg_bot=TgBot(
            token=env("BOT_TOKEN"),
            admin_ids=list(map(int, env.list("ADMIN_IDS")))
        )
    )

if __name__ == "__main__":
    config: Config = load_config()
    print("BOT_TOKEN:", config.tg_bot.token)
    print("ADMIN_IDS:", config.tg_bot.admin_ids)
```

---

_Last updated: 2025-06-21_
